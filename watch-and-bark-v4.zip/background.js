importScripts('shared.js', 'extractor.js');
let running = false, offscreenReady = null;
const sleep = ms => new Promise(r => setTimeout(r, ms));

/* ---------- Offscreen helper (sound + HTML parsing) ---------- */
async function ensureOffscreen() {
  if (await chrome.offscreen.hasDocument()) return;
  if (!offscreenReady) offscreenReady = chrome.offscreen.createDocument({ url: 'offscreen.html', reasons: ['AUDIO_PLAYBACK', 'DOM_PARSER'], justification: 'Play alert sounds and read job listing pages' }).finally(() => offscreenReady = null);
  await offscreenReady;
}

/* ---------- Reading a job page ---------- */
async function readByFetch(w) {
  const res = await fetch(w.url, { credentials: 'include', cache: 'no-store' });
  if (!res.ok) throw new Error(`${siteName(w.url)} returned HTTP ${res.status}`);
  const html = await res.text();
  await ensureOffscreen();
  const r = await chrome.runtime.sendMessage({ type: 'parse', html, url: res.url || w.url, pattern: w.pattern });
  if (!r?.ok) throw new Error(r?.error || 'Could not read page');
  return r;
}
function waitForLoad(tabId, timeout = 30000) {
  return new Promise(resolve => {
    const done = () => { clearTimeout(t); chrome.tabs.onUpdated.removeListener(l); resolve(); };
    const l = (id, info) => { if (id === tabId && info.status === 'complete') done(); };
    const t = setTimeout(done, timeout);
    chrome.tabs.onUpdated.addListener(l);
  });
}
async function waitForRender(tabId) {
  // Some job boards (e.g. single-page apps that show "Loading jobs…") build their
  // results after the page "load" event, and how long that takes varies with the
  // user's connection and the site's own speed. Instead of a fixed pause, poll the
  // page until the number of links on it stops changing (or we hit a sane cap).
  let last = -1, stable = 0;
  for (let i = 0; i < 14; i++) { // up to ~14s of polling
    await sleep(1000);
    let count = 0;
    try {
      const [r] = await chrome.scripting.executeScript({ target: { tabId }, func: () => document.querySelectorAll('a[href]').length });
      count = r?.result || 0;
    } catch { break; }
    if (count === last && count > 0) { stable++; if (stable >= 2) break; } else { stable = 0; }
    last = count;
  }
  await sleep(500); // small settle buffer
}
async function readByTab(w) {
  const { tabs: tabMap = {} } = await chrome.storage.local.get('tabs');
  let tab = null;
  if (tabMap[w.id]) tab = await chrome.tabs.get(tabMap[w.id]).catch(() => null);
  if (tab) { await chrome.tabs.update(tab.id, { url: w.url }); }
  else { tab = await chrome.tabs.create({ url: w.url, active: false, pinned: true }); tabMap[w.id] = tab.id; await chrome.storage.local.set({ tabs: tabMap }); }
  await waitForLoad(tab.id);
  await waitForRender(tab.id); // let JavaScript-built pages finish loading their results
  const [res] = await chrome.scripting.executeScript({ target: { tabId: tab.id }, func: extractJobs, args: [{ pattern: w.pattern }] });
  return res.result;
}
async function readWatch(w) {
  const method = w.method || 'auto';
  if (method === 'tab') return { ...(await readByTab(w)), via: 'tab' };
  let r, err;
  try { r = await readByFetch(w); } catch (e) { err = e; }
  if (r?.jobs?.length || method === 'fetch') { if (!r) throw err; return { ...r, via: 'fetch' }; }
  return { ...(await readByTab(w)), via: 'tab' };
}

/* ---------- Rules ---------- */
const list = s => s.split(/[,\n]/).map(x => x.trim().toLowerCase()).filter(Boolean);
function keywordDecide(job, s) {
  const hay = `${job.title} ${job.snippet}`.toLowerCase();
  const inc = list(s.include), exc = list(s.exclude), loc = list(s.locations);
  const hitExc = exc.find(k => hay.includes(k));
  if (hitExc) return { match: false, reason: `Excluded: "${hitExc}"` };
  const hitInc = inc.find(k => hay.includes(k));
  if (inc.length && !hitInc) return { match: false, reason: 'No include keyword' };
  const hitLoc = loc.find(k => hay.includes(k));
  if (loc.length && !hitLoc) return { match: false, reason: 'Location not in list' };
  return { match: true, reason: [hitInc && `Keyword "${hitInc}"`, hitLoc && `in ${hitLoc}`].filter(Boolean).join(' ') || 'Matches filters' };
}
async function fetchDetails(url) {
  try {
    await ensureOffscreen();
    const html = await (await fetch(url, { credentials: 'include' })).text();
    return html.replace(/<script[\s\S]*?<\/script>|<style[\s\S]*?<\/style>|<nav[\s\S]*?<\/nav>|<header[\s\S]*?<\/header>|<footer[\s\S]*?<\/footer>/gi, ' ')
      .replace(/<[^>]+>/g, ' ').replace(/&nbsp;/g, ' ').replace(/&amp;/g, '&').replace(/\s+/g, ' ').trim().slice(0, 3500);
  } catch { return ''; }
}
async function aiText(s, system, user, json = true) {
  if (!s.aiKey) throw new Error('Add your AI API key in Settings → When to bark → AI rule');
  const model = s.aiModel || DEFAULT_MODELS[s.aiProvider];
  if (s.aiProvider === 'openai') {
    const r = await fetch('https://api.openai.com/v1/chat/completions', { method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + s.aiKey },
      body: JSON.stringify({ model, ...(json ? { response_format: { type: 'json_object' } } : {}), messages: [{ role: 'system', content: system }, { role: 'user', content: user }] }) });
    const d = await r.json(); if (!r.ok) throw new Error(d.error?.message || 'OpenAI HTTP ' + r.status);
    return d.choices[0].message.content;
  }
  const r = await fetch('https://api.anthropic.com/v1/messages', { method: 'POST',
    headers: { 'Content-Type': 'application/json', 'x-api-key': s.aiKey, 'anthropic-version': '2023-06-01', 'anthropic-dangerous-direct-browser-access': 'true' },
    body: JSON.stringify({ model, max_tokens: 2000, system, messages: [{ role: 'user', content: user }] }) });
  const d = await r.json(); if (!r.ok) throw new Error(d.error?.message || 'Anthropic HTTP ' + r.status);
  return d.content.map(c => c.text || '').join('');
}
const parseJSON = t => JSON.parse(t.slice(t.indexOf('{'), t.lastIndexOf('}') + 1));
const jobPayload = (jobs, full) => jobs.map((j, i) => ({ id: 'j' + i, site: j.site, title: j.title, listing_text: j.snippet, ...(full && j.details ? { full_description: j.details } : {}) }));

async function callAI(s, jobs, rule) {
  const system = 'You screen job listings for one person. For each job decide if it matches their alert rule. ' +
    'The rule may be written loosely (e.g. a job title or seniority level) — use your own knowledge to cover the usual equivalents and near-matches for it ' +
    '(for example, in UK medical training grades, "junior doctor" normally covers Foundation Year 1–2 (FY1/F1, FY2/F2) and Core/Specialty Training CT1–CT2, and job titles like "Senior House Officer (SHO)" overlap too) — decide sensibly rather than requiring an exact text match. ' +
    'Respond ONLY with JSON: {"results":[{"id":"j0","match":true,"reason":"why, max 12 words"}]}. Include every job id.';
  const user = `Today is ${new Date().toDateString()}.\nALERT RULE:\n${rule ?? s.aiRule}\n\nJOBS:\n${JSON.stringify(jobPayload(jobs, true), null, 1)}`;
  const json = parseJSON(await aiText(s, system, user));
  const out = {};
  for (const r of json.results || []) { const j = jobs[+String(r.id).slice(1)]; if (j) out[j.uid] = { match: !!r.match, reason: r.reason || '' }; }
  return out;
}
async function aiSearch(s, question) {
  const watches = s.watches.filter(w => w.enabled !== false);
  const g = await chrome.storage.local.get(watches.map(w => 'w_' + w.id));
  const jobs = watches.flatMap(w => g['w_' + w.id]?.jobs || []).slice(0, 80);
  if (!jobs.length) throw new Error('No jobs loaded yet — add a website and wait for the first check.');
  const system = 'You help a job seeker search the job listings they are watching. Answer their question using ONLY the listings given. ' +
    'Respond ONLY with JSON: {"answer":"short helpful answer, max 60 words","ids":["j0","j3"]} where ids are the listings that answer the question, best first. Use an empty list if none fit.';
  const user = `Today is ${new Date().toDateString()}.\nQUESTION: ${question}\n\nLISTINGS:\n${JSON.stringify(jobPayload(jobs), null, 1)}`;
  const json = parseJSON(await aiText(s, system, user));
  return { answer: json.answer || '', uids: (json.ids || []).map(id => jobs[+String(id).slice(1)]?.uid).filter(Boolean) };
}
async function aiImprove(s, wish) {
  const system = 'Turn the job seeker\'s wish into a clear alert rule that another AI will use to decide, job by job, whether to alert them. ' +
    'Cover: roles/titles, specialty or field, seniority/grade, locations, things to skip, and deadlines or contract type if mentioned. ' +
    'Write 2–4 plain sentences ("Bark for…", "Skip…"). Do not invent requirements they did not ask for. Output only the rule text.';
  return (await aiText(s, system, wish, false)).trim().replace(/^"|"$/g, '');
}
async function evaluateGlobal(jobs, s) {
  const out = {};
  if (!jobs.length) return { decisions: out };
  if (s.mode === 'keywords') { jobs.forEach(j => out[j.uid] = keywordDecide(j, s)); return { decisions: out }; }
  if (s.mode !== 'ai') { jobs.forEach(j => out[j.uid] = { match: true, reason: 'New job' }); return { decisions: out }; }
  if (!s.aiKey || !s.aiRule.trim()) throw new Error('AI rule or API key missing — open Settings');
  const batch = jobs.slice(0, 25);
  if (s.aiDetails) await Promise.all(batch.map(async j => { j.details = await fetchDetails(j.url); }));
  try {
    Object.assign(out, await callAI(s, batch));
    batch.forEach(j => { if (!out[j.uid]) out[j.uid] = { match: s.aiFailOpen, reason: 'AI gave no answer' }; });
    return { decisions: out };
  } catch (e) {
    batch.forEach(j => out[j.uid] = { match: s.aiFailOpen, reason: 'AI unavailable' + (s.aiFailOpen ? ' — barking to be safe' : '') });
    return { decisions: out, aiError: String(e.message || e) };
  }
}
// A website can carry its own "what jobs are you looking for" text (w.aiWish). When it does,
// that website's new jobs are screened by AI against that description — on top of, and
// independent from, the global mode/keyword/AI-rule settings used for every other website.
async function evaluate(jobs, s) {
  const out = {};
  if (!jobs.length) return { decisions: out };
  const wishJobs = jobs.filter(j => j.wish && j.wish.trim());
  const restJobs = jobs.filter(j => !(j.wish && j.wish.trim()));
  let aiError = null;
  if (wishJobs.length) {
    if (!s.aiKey) {
      wishJobs.forEach(j => out[j.uid] = { match: true, reason: 'New job (add an AI key in Settings to let AI filter this site)' });
    } else {
      const byWatch = new Map();
      for (const j of wishJobs) { if (!byWatch.has(j.wid)) byWatch.set(j.wid, []); byWatch.get(j.wid).push(j); }
      for (const [, list] of byWatch) {
        const rule = list[0].wish;
        const batch = list.slice(0, 25);
        if (s.aiDetails) await Promise.all(batch.map(async j => { j.details = await fetchDetails(j.url); }));
        try {
          Object.assign(out, await callAI(s, batch, rule));
          batch.forEach(j => { if (!out[j.uid]) out[j.uid] = { match: s.aiFailOpen, reason: 'AI gave no answer' }; });
        } catch (e) {
          batch.forEach(j => out[j.uid] = { match: s.aiFailOpen, reason: 'AI unavailable' + (s.aiFailOpen ? ' — barking to be safe' : '') });
          aiError = aiError || String(e.message || e);
        }
        list.slice(25).forEach(j => out[j.uid] = { match: true, reason: 'New job' });
      }
    }
  }
  if (restJobs.length) {
    try {
      const r2 = await evaluateGlobal(restJobs, s);
      Object.assign(out, r2.decisions);
      aiError = aiError || r2.aiError || null;
    } catch (e) { throw e; }
  }
  return { decisions: out, ...(aiError ? { aiError } : {}) };
}

/* ---------- Alerts ---------- */
const inQuietHours = s => s.quietOn && inWindow(s.quietStart, s.quietEnd);
async function play(s) {
  try {
    await ensureOffscreen();
    const custom = s.sound === 'custom' ? (await chrome.storage.local.get('customSound')).customSound?.data : null;
    await chrome.runtime.sendMessage({ type: 'play', sound: s.sound, volume: s.volume, repeats: s.repeats, custom });
  } catch (e) { console.warn('sound failed', e); }
}
const setBadge = n => { chrome.action.setBadgeBackgroundColor({ color: '#d32f2f' }); chrome.action.setBadgeText({ text: n ? String(n) : '' }); };
async function sendPush(pushUrl, title, lines, url) {
  if (!pushUrl) return;
  try {
    const u = new URL(pushUrl);
    if (!(await chrome.permissions.contains({ origins: [u.origin + '/*'] }))) return;
    const text = [title, ...lines, url || ''].filter(Boolean).join('\n');
    if (/discord(app)?\.com$/.test(u.hostname)) await fetch(pushUrl, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ content: text }) });
    else if (/hooks\.slack\.com$/.test(u.hostname)) await fetch(pushUrl, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ text }) });
    else await fetch(pushUrl, { method: 'POST', body: lines.join('\n') || title, headers: { Title: title.replace(/[^\x20-\x7E]/g, '').trim() || 'Watch & Bark', Tags: 'dog', ...(url ? { Click: url } : {}) } }); // ntfy
  } catch (e) { console.warn('push failed', e); }
}
async function alertJobs(matched, s, test = false) {
  sendPush(s.pushUrl, test ? 'Watch & Bark test' : matched.length === 1 ? 'Woof! New matching job' : `Woof! ${matched.length} new matching jobs`,
    matched.slice(0, 5).map(j => '• ' + j.title + (j.site ? ' (' + j.site + ')' : '')), test ? '' : matched[0]?.url);
  if (!inQuietHours(s)) await play(s);
  if (s.notify) {
    const id = 'wb-' + Date.now();
    chrome.notifications.create(id, {
      type: 'basic', iconUrl: 'icon128.png', priority: 2, requireInteraction: true,
      buttons: test ? [] : [{ title: 'Open job' }, { title: 'Mark all read' }],
      title: test ? '🐶 Woof! This is a test' : matched.length === 1 ? '🐶 Woof! New matching job' : `🐶 Woof! ${matched.length} new matching jobs`,
      message: matched.slice(0, 3).map(j => j.title).join('\n'),
      contextMessage: test ? 'Watch & Bark' : `${matched[0].site}${matched[0].reason ? ' · ' + matched[0].reason : ''}`
    });
    if (!test) { const { notifUrls = {} } = await chrome.storage.local.get('notifUrls'); notifUrls[id] = matched[0].url; await chrome.storage.local.set({ notifUrls }); }
  }
  if (test) return;
  const st = await chrome.storage.local.get(['unread', 'history']);
  const unread = (st.unread || 0) + matched.length;
  const history = [...matched.map(j => ({ title: j.title, url: j.url, site: j.site, reason: j.reason, at: Date.now() })), ...(st.history || [])].slice(0, 100);
  await chrome.storage.local.set({ unread, history });
  setBadge(unread);
  if (s.persistent) chrome.alarms.create('nag', { periodInMinutes: 1 });
}

/* ---------- Main check ---------- */
async function checkWatch(w, s) {
  const stKey = 'w_' + w.id;
  const prev = (await chrome.storage.local.get(stKey))[stKey] || {};
  try {
    const r = await readWatch(w);
    const site = w.name || siteName(w.url);
    const jobs = (r.jobs || []).map(j => ({ ...j, uid: w.id + '|' + j.key, site, wid: w.id, wish: w.aiWish || '' }));
    if (!jobs.length) throw new Error('No job links found on this page. Open Settings → Test this page.');
    const firstRun = !prev.seen;
    const seen = new Set(prev.seen || []);
    const fresh = jobs.filter(j => !seen.has(j.key));
    jobs.forEach(j => seen.add(j.key));
    await chrome.storage.local.set({ [stKey]: { seen: [...seen].slice(-3000), jobs, lastCheck: Date.now(), via: r.via, strategy: r.strategy, error: null } });
    return firstRun ? [] : fresh;
  } catch (e) {
    await chrome.storage.local.set({ [stKey]: { ...prev, lastCheck: Date.now(), error: String(e.message || e) } });
    return [];
  }
}
async function check(manual = false) {
  if (running) return { ok: false, error: 'Already checking' };
  running = true;
  try {
    const s = await getSettings();
    if (!manual && (s.paused || Date.now() < (s.snoozeUntil || 0))) return { ok: true, paused: true };
    if (!manual && s.activeOn && !inWindow(s.activeStart, s.activeEnd)) return { ok: true, outsideHours: true };
    const watches = s.watches.filter(w => w.enabled !== false && w.url);
    let fresh = [];
    for (const w of watches) fresh = fresh.concat(await checkWatch(w, s));
    const st = await chrome.storage.local.get(['decisions', 'newIds', 'unread']);
    const decisions = st.decisions || {}, newIds = new Set(st.newIds || []);
    let aiError = null, matched = [];
    if (fresh.length) {
      const r = await evaluate(fresh.map(j => ({ ...j })), s);
      aiError = r.aiError || null;
      Object.assign(decisions, r.decisions);
      fresh.forEach(j => newIds.add(j.uid));
      matched = fresh.filter(j => decisions[j.uid]?.match).map(j => ({ ...j, reason: decisions[j.uid].reason }));
    }
    // prune old decisions
    const ids = Object.keys(decisions); if (ids.length > 1500) ids.slice(0, ids.length - 1500).forEach(k => delete decisions[k]);
    await chrome.storage.local.set({ decisions, newIds: [...newIds].slice(-500), lastCheck: Date.now(), aiError });
    if (matched.length && !s.paused) await alertJobs(matched, s);
    else setBadge(st.unread || 0);
    return { ok: true, fresh: fresh.length, matched: matched.length };
  } finally { running = false; }
}
/* ---------- Timers (any interval, down to 1 second) ----------
   setTimeout loops do the precise timing; a 30-second alarm wakes the
   service worker if Chrome put it to sleep, and re-arms anything overdue. */
const loops = {};
function arm(name, dueAt, fn) { clearTimeout(loops[name]); loops[name] = setTimeout(fn, Math.max(0, dueAt - Date.now())); }

async function armCheck(reset = false) {
  const s = await getSettings(), base = checkSeconds(s) * 1000;
  const every = s.jitter ? Math.round(base * (0.8 + Math.random() * 0.4)) : base; // vary ±20%
  let { nextCheckAt } = await chrome.storage.local.get('nextCheckAt');
  if (reset || !nextCheckAt || nextCheckAt - Date.now() > every) { nextCheckAt = Date.now() + Math.min(every, 5000); await chrome.storage.local.set({ nextCheckAt }); }
  arm('check', nextCheckAt, async () => {
    await chrome.storage.local.set({ nextCheckAt: Date.now() + every });
    await check().catch(e => console.warn(e));
    armCheck();
  });
}

/* Page auto-refresher */
async function getRefreshers() { return (await chrome.storage.local.get('refreshers')).refreshers || {}; }
const nextDelay = r => 1000 * (r.random ? r.minSec + Math.random() * (r.maxSec - r.minSec) : r.seconds);
async function pageHasText(tabId, text) {
  await waitForLoad(tabId, 20000); await sleep(1500);
  const [res] = await chrome.scripting.executeScript({ target: { tabId }, func: t => (document.body?.innerText || '').toLowerCase().includes(t.toLowerCase()), args: [text] });
  return !!res?.result;
}
async function armRefresher(tabId) {
  const all = await getRefreshers(), r = all[tabId];
  if (!r) { clearTimeout(loops['r' + tabId]); return; }
  arm('r' + tabId, r.nextAt, async () => {
    const cur = await getRefreshers(); const x = cur[tabId]; if (!x) return;
    try { await chrome.tabs.reload(+tabId, { bypassCache: !!x.hard }); }
    catch { delete cur[tabId]; await chrome.storage.local.set({ refreshers: cur }); return; } // tab closed
    x.count = (x.count || 0) + 1;
    x.nextAt = Date.now() + nextDelay(x);
    let stop = x.maxCount && x.count >= x.maxCount;
    if (x.keyword) {
      try {
        const found = await pageHasText(+tabId, x.keyword);
        const hit = x.kwMode === 'disappears' ? (!found && x.lastFound === true) : (found && x.lastFound !== true);
        x.lastFound = found; x.kwError = null;
        if (hit) {
          const s = await getSettings();
          if (!inQuietHours(s)) play(s);
          const title = `Woof! "${x.keyword}" ${x.kwMode === 'disappears' ? 'disappeared from' : 'appeared on'} the page`;
          chrome.notifications.create('kw-' + Date.now(), { type: 'basic', iconUrl: 'icon128.png', priority: 2, requireInteraction: true, title: '🐶 ' + title, message: x.title || '', contextMessage: 'Auto-refresh · page monitor' });
          sendPush(s.pushUrl, title, [x.title || ''], x.url);
          x.lastHitAt = Date.now();
          if (x.kwStop) stop = true;
        }
      } catch (e) { x.kwError = 'Could not read the page: ' + (e.message || e); }
    }
    const latest = await getRefreshers();
    if (!latest[tabId]) return; // stopped meanwhile
    if (stop) { delete latest[tabId]; await chrome.storage.local.set({ refreshers: latest }); return; }
    latest[tabId] = x; await chrome.storage.local.set({ refreshers: latest });
    armRefresher(tabId);
  });
}
async function startRefresh(tabId, cfg) {
  const all = await getRefreshers();
  const r = { ...cfg, count: 0, lastFound: null };
  r.nextAt = Date.now() + nextDelay(r);
  all[tabId] = r;
  await chrome.storage.local.set({ refreshers: all }); armRefresher(tabId);
  if (r.keyword) pageHasText(+tabId, r.keyword).then(async f => { const a = await getRefreshers(); if (a[tabId]) { a[tabId].lastFound = f; await chrome.storage.local.set({ refreshers: a }); } }).catch(() => {});
}
async function stopRefresh(tabId) {
  const all = await getRefreshers(); delete all[tabId];
  await chrome.storage.local.set({ refreshers: all }); clearTimeout(loops['r' + tabId]);
}
async function armAll() {
  armCheck();
  const all = await getRefreshers();
  for (const id of Object.keys(all)) armRefresher(id);
  chrome.alarms.clear('check'); // from older versions
  chrome.alarms.create('guard', { periodInMinutes: 0.5 });
}
chrome.tabs.onRemoved.addListener(id => stopRefresh(id));

chrome.runtime.onInstalled.addListener(d => { armAll(); if (d.reason === 'install') chrome.runtime.openOptionsPage(); });
chrome.runtime.onStartup.addListener(armAll);
chrome.storage.onChanged.addListener(c => {
  if (c.settings && checkSeconds(c.settings.oldValue || {}) !== checkSeconds(c.settings.newValue || {})) armCheck(true);
});
chrome.alarms.onAlarm.addListener(async a => {
  if (a.name === 'guard') armAll();
  if (a.name === 'nag') { const s = await getSettings(); if (!inQuietHours(s)) play(s); }
});
armAll(); // service worker woke up
chrome.notifications.onButtonClicked.addListener(async (id, btn) => {
  if (btn === 0) { const { notifUrls = {} } = await chrome.storage.local.get('notifUrls'); if (notifUrls[id]) chrome.tabs.create({ url: notifUrls[id] }); }
  else { await chrome.storage.local.set({ unread: 0, newIds: [] }); await chrome.alarms.clear('nag'); setBadge(0); }
  chrome.notifications.clear(id);
});
chrome.notifications.onClicked.addListener(async id => {
  const { notifUrls = {} } = await chrome.storage.local.get('notifUrls');
  if (notifUrls[id]) chrome.tabs.create({ url: notifUrls[id] });
  delete notifUrls[id]; chrome.storage.local.set({ notifUrls }); chrome.notifications.clear(id);
});

chrome.runtime.onMessage.addListener((msg, _s, reply) => {
  if (!['checkNow', 'testAlert', 'playSound', 'markRead', 'preview', 'testWatch', 'startRefresh', 'stopRefresh', 'aiSearch', 'aiImprove', 'testPush'].includes(msg.type)) return;
  const r = p => { p.then(reply, e => reply({ ok: false, error: String(e.message || e) })); return true; };
  switch (msg.type) {
    case 'checkNow': return r(check(true));
    case 'startRefresh': return r(startRefresh(msg.tabId, msg.cfg).then(() => ({ ok: true })));
    case 'aiSearch': return r(getSettings().then(s => aiSearch(Object.assign(s, msg.settings || {}), msg.question)).then(x => ({ ok: true, ...x })));
    case 'aiImprove': return r(getSettings().then(s => aiImprove(Object.assign(s, msg.settings || {}), msg.wish)).then(rule => ({ ok: true, rule })));
    case 'testPush': return r(sendPush(msg.url, 'Watch & Bark test', ['Woof! Phone alerts are working.'], '').then(() => ({ ok: true })));
    case 'stopRefresh': return r(stopRefresh(msg.tabId).then(() => ({ ok: true })));
    case 'testAlert': return r(getSettings().then(s => alertJobs([{ title: 'This is how a new job alert looks' }], s, true)).then(() => ({ ok: true })));
    case 'playSound': return r(play(msg.settings).then(() => ({ ok: true })));
    case 'markRead': return r((async () => { await chrome.storage.local.set({ unread: 0, newIds: [] }); await chrome.alarms.clear('nag'); setBadge(0); return { ok: true }; })());
    case 'testWatch': return r((async () => {
      const res = await readWatch(msg.watch);
      const wish = (msg.watch.aiWish || '').trim();
      if (!wish || !res.jobs?.length) return { ok: true, ...res };
      const s = await getSettings();
      if (!s.aiKey) return { ok: true, ...res, wishError: 'Add an AI key in Settings → When to bark → AI rule to let AI filter this site.' };
      const sample = res.jobs.slice(0, 15).map((j, i) => ({ ...j, uid: 'p' + i }));
      try {
        const decisions = await callAI(s, sample, wish);
        return { ok: true, ...res, wishPreview: sample.map(j => ({ title: j.title, match: !!decisions[j.uid]?.match, reason: decisions[j.uid]?.reason || '' })) };
      } catch (e) { return { ok: true, ...res, wishError: String(e.message || e) }; }
    })());
    case 'preview': return r((async () => {
      const s = Object.assign(await getSettings(), msg.settings || {});
      const all = [];
      for (const w of s.watches) { const st = (await chrome.storage.local.get('w_' + w.id))['w_' + w.id]; (st?.jobs || []).forEach(j => all.push(j)); }
      if (!all.length) throw new Error('No jobs loaded yet — add a website above, save, and wait for the first check.');
      const jobs = all.slice(0, 15);
      return { ok: true, jobs, ...(await evaluate(jobs.map(j => ({ ...j })), s)) };
    })());
  }
});
