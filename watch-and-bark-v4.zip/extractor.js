// Self-contained: runs inside a web page (chrome.scripting) or the offscreen parser.
function extractJobs(opts) {
  opts = opts || {};
  const doc = opts.__doc || document;
  const base = opts.base || location.href;
  const host = (() => { try { return new URL(base).hostname; } catch { return ''; } })();
  const KNOWN = [
    [/jobs\.nhs\.uk$/, /\/candidate\/jobadvert\//],
    [/(^|\.)indeed\./, /(\/viewjob|\/rc\/clk|[?&](jk|vjk)=)/],
    [/linkedin\.com$/, /\/jobs\/view\//],
    [/reed\.co\.uk$/, /\/jobs\/[^/]+\/\d+/],
    [/(totaljobs|cwjobs|stepstone|caterer|jobsite)\./, /\/job\//],
    [/glassdoor\./, /(job-listing|jobListing)/],
    [/(^|\.)monster\./, /\/job-openings?\//],
    [/seek\.com/, /\/job\/\d+/],
    [/naukri\.com$/, /job-listings/],
    [/rozee\.pk$/, /(-jobs?-\d+|\/job\/)/],
    [/bayt\.com$/, /\/job\//],
    [/healthjobsuk\.com$/, /\/job\//],
    [/careers\.bmj\.com$/, /\/job\//]
  ];
  const ID_PARAMS = ['jk', 'vjk', 'id', 'jobid', 'job_id', 'jobId', 'currentJobId', 'jobkey', 'reqid'];
  const clean = s => (s || '').replace(/\s+/g, ' ').trim();
  const keyOf = u => {
    const kept = ID_PARAMS.filter(p => u.searchParams.get(p)).map(p => p + '=' + u.searchParams.get(p)).join('&');
    return u.hostname.replace(/^www\./, '') + u.pathname.replace(/\/$/, '') + (kept ? '?' + kept : '');
  };
  const all = [];
  for (const a of doc.querySelectorAll('a[href]')) {
    let u; try { u = new URL(a.getAttribute('href'), base); } catch { continue; }
    if (!/^https?:$/.test(u.protocol)) continue;
    const text = clean(a.innerText || a.textContent) || clean(a.getAttribute('aria-label') || a.getAttribute('title'));
    all.push({ a, u, text });
  }
  let picked, strategy;
  if (opts.pattern) {
    let re = null; const p = opts.pattern.trim();
    if (/^\/.+\/[a-z]*$/.test(p)) { try { const i = p.lastIndexOf('/'); re = new RegExp(p.slice(1, i), p.slice(i + 1)); } catch {} }
    picked = all.filter(x => re ? re.test(x.u.href) : x.u.href.includes(p)); strategy = 'your link pattern';
  } else {
    const k = KNOWN.find(([h]) => h.test(host));
    if (k) { picked = all.filter(x => k[1].test(x.u.href)); strategy = 'known site'; }
    if (!picked || !picked.length) {
      const groups = new Map();
      const basePath = (() => { try { return new URL(base).pathname; } catch { return ''; } })();
      for (const x of all) {
        if (x.text.length < 6 || x.u.pathname === basePath || x.u.pathname.split('/').filter(Boolean).length < 1) continue;
        const sig = x.u.hostname + '/' + x.u.pathname.split('/').filter(Boolean).map(s => (/\d/.test(s) || s.length > 24) ? '*' : s).join('/');
        if (!sig.includes('*')) continue;
        if (!groups.has(sig)) groups.set(sig, []);
        groups.get(sig).push(x);
      }
      let best = null, bestScore = 0;
      for (const [sig, xs] of groups) {
        const keys = new Set(xs.map(x => keyOf(x.u)));
        if (keys.size < 2) continue;
        const avg = xs.reduce((n, x) => n + x.text.length, 0) / xs.length;
        const score = keys.size + (/job|vacanc|position|career|advert|posting|opening|role|vacature|stelle|empleo/i.test(sig) ? 6 : 0) + (avg >= 12 ? 3 : 0);
        if (score > bestScore) { bestScore = score; best = xs; }
      }
      picked = best || []; strategy = 'auto-detected';
    }
  }
  const byKey = new Map();
  for (const x of picked) {
    const key = keyOf(x.u);
    const cur = byKey.get(key);
    if (!cur) byKey.set(key, { key, url: x.u.href, title: x.text, els: [x.a] });
    else { cur.els.push(x.a); if (x.text.length > cur.title.length && x.text.length < 160) cur.title = x.text; }
  }
  const pickedEls = new Map(); for (const j of byKey.values()) for (const e of j.els) pickedEls.set(e, j.key);
  const jobs = [];
  for (const j of byKey.values()) {
    if (!j.title) continue;
    let el = j.els[0];
    for (let i = 0; i < 8 && el.parentElement; i++) {
      const p = el.parentElement;
      const keys = new Set([...p.querySelectorAll('a[href]')].map(e => pickedEls.get(e)).filter(Boolean));
      if (keys.size > 1 || clean(p.textContent).length > 900) break;
      el = p;
    }
    const parts = []; const tw = doc.createTreeWalker(el, 4); let n;
    while ((n = tw.nextNode())) { const t = clean(n.nodeValue); if (t && t !== j.title && !parts.includes(t)) parts.push(t); }
    const snippet = parts.join(' · ');
    jobs.push({ key: j.key, url: j.url, title: j.title.slice(0, 160), snippet: snippet.slice(0, 280) });
    if (jobs.length >= 60) break;
  }
  return { jobs, strategy };
}
