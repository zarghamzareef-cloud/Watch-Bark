/* ---------- HTML parsing for fetched pages ---------- */
chrome.runtime.onMessage.addListener((msg, _s, reply) => {
  if (msg.type === 'parse') {
    try {
      const doc = new DOMParser().parseFromString(msg.html, 'text/html');
      doc.querySelectorAll('script,style,noscript,svg').forEach(e => e.remove());
      reply({ ok: true, ...extractJobs({ __doc: doc, base: msg.url, pattern: msg.pattern }) });
    } catch (e) { reply({ ok: false, error: String(e) }); }
    return true;
  }
  if (msg.type === 'play') { play(msg); reply({ ok: true }); }
});

/* ---------- Sounds ---------- */
let ctx;
function bark(t, vol, pitch = 1, len = 1) {
  // voiced part
  const o = ctx.createOscillator(), o2 = ctx.createOscillator(), f1 = ctx.createBiquadFilter(), f2 = ctx.createBiquadFilter(), g = ctx.createGain();
  const p0 = 330 * pitch, d = 0.17 * len;
  for (const osc of [o, o2]) { osc.type = 'sawtooth'; osc.frequency.setValueAtTime(p0, t); osc.frequency.exponentialRampToValueAtTime(p0 * 1.6, t + 0.025 * len); osc.frequency.exponentialRampToValueAtTime(p0 * 0.55, t + d); }
  o2.detune.value = 18;
  f1.type = 'bandpass'; f1.frequency.setValueAtTime(1100 * pitch, t); f1.frequency.exponentialRampToValueAtTime(600 * pitch, t + d); f1.Q.value = 2.5;
  f2.type = 'lowpass'; f2.frequency.value = 2600 * pitch;
  g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(vol, t + 0.01); g.gain.setValueAtTime(vol, t + 0.04 * len); g.gain.exponentialRampToValueAtTime(0.0001, t + d);
  o.connect(f1); o2.connect(f1); f1.connect(f2).connect(g).connect(ctx.destination);
  o.start(t); o2.start(t); o.stop(t + d + 0.02); o2.stop(t + d + 0.02);
  // breathy noise burst
  const n = ctx.sampleRate * 0.09 * len | 0, b = ctx.createBuffer(1, n, ctx.sampleRate), ch = b.getChannelData(0);
  for (let i = 0; i < n; i++) ch[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / n, 2);
  const s = ctx.createBufferSource(), nf = ctx.createBiquadFilter(), ng = ctx.createGain();
  s.buffer = b; nf.type = 'bandpass'; nf.frequency.value = 1500 * pitch; nf.Q.value = 0.9; ng.gain.value = vol * 0.45;
  s.connect(nf).connect(ng).connect(ctx.destination); s.start(t);
}
function tone(t, f, type, d, vol, g = 0.6) {
  const o = ctx.createOscillator(), gn = ctx.createGain();
  o.type = type; o.frequency.value = f;
  gn.gain.setValueAtTime(0.0001, t); gn.gain.exponentialRampToValueAtTime(Math.max(0.0002, vol * g), t + 0.01); gn.gain.exponentialRampToValueAtTime(0.0001, t + d);
  o.connect(gn).connect(ctx.destination); o.start(t); o.stop(t + d + 0.05);
}
function howl(t, vol) {
  const o = ctx.createOscillator(), lfo = ctx.createOscillator(), lg = ctx.createGain(), f = ctx.createBiquadFilter(), g = ctx.createGain();
  o.type = 'sawtooth'; o.frequency.setValueAtTime(380, t); o.frequency.linearRampToValueAtTime(720, t + 0.5); o.frequency.linearRampToValueAtTime(680, t + 1.1); o.frequency.linearRampToValueAtTime(420, t + 1.6);
  lfo.frequency.value = 5.5; lg.gain.value = 12; lfo.connect(lg).connect(o.frequency);
  f.type = 'bandpass'; f.frequency.value = 900; f.Q.value = 3;
  g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(vol * 0.9, t + 0.25); g.gain.setValueAtTime(vol * 0.9, t + 1.2); g.gain.exponentialRampToValueAtTime(0.0001, t + 1.65);
  o.connect(f).connect(g).connect(ctx.destination); o.start(t); lfo.start(t); o.stop(t + 1.7); lfo.stop(t + 1.7);
}
function noiseBurst(t, d, vol, freq, q = 1) {
  const n = ctx.sampleRate * d | 0, b = ctx.createBuffer(1, n, ctx.sampleRate), ch = b.getChannelData(0);
  for (let i = 0; i < n; i++) ch[i] = (Math.random() * 2 - 1) * (1 - i / n);
  const s = ctx.createBufferSource(), f = ctx.createBiquadFilter(), g = ctx.createGain();
  s.buffer = b; f.type = 'bandpass'; f.frequency.value = freq; f.Q.value = q; g.gain.value = vol;
  s.connect(f).connect(g).connect(ctx.destination); s.start(t);
}
function slide(t, f0, f1, d, type, vol, g = 0.5) {
  const o = ctx.createOscillator(), gn = ctx.createGain();
  o.type = type; o.frequency.setValueAtTime(f0, t); o.frequency.exponentialRampToValueAtTime(f1, t + d);
  gn.gain.setValueAtTime(0.0001, t); gn.gain.exponentialRampToValueAtTime(vol * g, t + 0.02); gn.gain.exponentialRampToValueAtTime(0.0001, t + d);
  o.connect(gn).connect(ctx.destination); o.start(t); o.stop(t + d + 0.05);
}
function growl(t, vol) {
  const o = ctx.createOscillator(), lfo = ctx.createOscillator(), lg = ctx.createGain(), f = ctx.createBiquadFilter(), g = ctx.createGain();
  o.type = 'sawtooth'; o.frequency.value = 95; lfo.type = 'square'; lfo.frequency.value = 28; lg.gain.value = 0.5;
  f.type = 'lowpass'; f.frequency.value = 700;
  g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(vol * 0.8, t + 0.15); g.gain.setValueAtTime(vol * 0.8, t + 0.55); g.gain.exponentialRampToValueAtTime(0.0001, t + 0.75);
  const am = ctx.createGain(); am.gain.value = 0.5; lfo.connect(lg).connect(am.gain);
  o.connect(f).connect(am).connect(g).connect(ctx.destination); o.start(t); lfo.start(t); o.stop(t + 0.8); lfo.stop(t + 0.8);
}
const PATTERNS = {
  bark:     { gap: 0.75, play: (t, v) => { bark(t, v); bark(t + 0.24, v * 0.9); } },
  bigdog:   { gap: 0.95, play: (t, v) => { bark(t, v, 0.62, 1.5); bark(t + 0.36, v, 0.6, 1.5); } },
  puppy:    { gap: 0.6,  play: (t, v) => { bark(t, v * 0.8, 1.9, 0.6); bark(t + 0.14, v * 0.8, 2.0, 0.55); bark(t + 0.28, v * 0.75, 2.1, 0.5); } },
  howl:     { gap: 1.9,  play: (t, v) => howl(t, v) },
  chime:    { gap: 0.9,  play: (t, v) => { tone(t, 880, 'sine', 0.35, v); tone(t + 0.18, 1320, 'sine', 0.5, v); } },
  dingdong: { gap: 1.3,  play: (t, v) => { tone(t, 659, 'sine', 0.7, v, 0.7); tone(t + 0.4, 523, 'sine', 0.9, v, 0.7); } },
  bell:     { gap: 1.5,  play: (t, v) => { tone(t, 660, 'triangle', 1.4, v); tone(t, 1320, 'sine', 1.0, v, 0.25); tone(t, 1980, 'sine', 0.6, v, 0.12); } },
  triple:   { gap: 0.95, play: (t, v) => { bark(t, v); bark(t + 0.22, v * 0.95); bark(t + 0.44, v); } },
  growl:    { gap: 1.4,  play: (t, v) => { growl(t, v); bark(t + 0.8, v, 0.8, 1.2); } },
  whine:    { gap: 1.3,  play: (t, v) => { slide(t, 900, 1500, 0.35, 'triangle', v); slide(t + 0.4, 1400, 800, 0.55, 'triangle', v); } },
  radar:    { gap: 1.2,  play: (t, v) => { tone(t, 1568, 'sine', 0.9, v, 0.55); tone(t + 0.02, 3136, 'sine', 0.4, v, 0.12); } },
  scanner:  { gap: 0.9,  play: (t, v) => { [0, 0.09, 0.18, 0.27].forEach((d, i) => tone(t + d, 1200 + i * 300, 'square', 0.07, v, 0.18)); slide(t + 0.4, 600, 2000, 0.3, 'sine', v, 0.5); } },
  marimba:  { gap: 1.0,  play: (t, v) => { [523, 659, 784, 1047].forEach((f, i) => { tone(t + i * 0.11, f, 'sine', 0.4, v, 0.6); tone(t + i * 0.11, f * 4, 'sine', 0.08, v, 0.1); }); } },
  pop:      { gap: 0.6,  play: (t, v) => { slide(t, 400, 1200, 0.08, 'sine', v, 0.8); slide(t + 0.12, 600, 1800, 0.08, 'sine', v, 0.7); } },
  coin:     { gap: 0.7,  play: (t, v) => { tone(t, 988, 'square', 0.08, v, 0.25); tone(t + 0.08, 1319, 'square', 0.35, v, 0.25); } },
  retro:    { gap: 1.0,  play: (t, v) => { [523, 659, 784, 1047, 784, 1047].forEach((f, i) => tone(t + i * 0.08, f, 'square', 0.09, v, 0.2)); } },
  harp:     { gap: 1.4,  play: (t, v) => { [392, 494, 587, 784, 988].forEach((f, i) => tone(t + i * 0.07, f, 'triangle', 1.0, v, 0.4)); } },
  siren:    { gap: 1.6,  play: (t, v) => { slide(t, 650, 1300, 0.7, 'sawtooth', v, 0.22); slide(t + 0.75, 1300, 650, 0.7, 'sawtooth', v, 0.22); } },
  doorbell: { gap: 1.6,  play: (t, v) => { tone(t, 784, 'sine', 0.9, v, 0.7); tone(t + 0.5, 622, 'sine', 1.1, v, 0.7); } },
  knock:    { gap: 1.0,  play: (t, v) => { [0, 0.18, 0.36].forEach(d => { noiseBurst(t + d, 0.08, v * 0.9, 180, 2); tone(t + d, 110, 'sine', 0.1, v, 0.6); }); } },
  alarm:    { gap: 0.75, play: (t, v) => { tone(t, 1000, 'square', 0.18, v, 0.3); tone(t + 0.22, 800, 'square', 0.18, v, 0.3); tone(t + 0.44, 1000, 'square', 0.18, v, 0.3); } }
};
function play(msg) {
  const vol = Math.max(0.05, Math.min(1, msg.volume ?? 0.8)), reps = Math.max(1, Math.min(10, msg.repeats || 1));
  if (msg.sound === 'custom' && msg.custom) {
    let n = 0; const a = new Audio(msg.custom); a.volume = vol;
    a.onended = () => { if (++n < reps) { a.currentTime = 0; a.play(); } };
    a.play().catch(() => {});
    return;
  }
  if (!ctx || ctx.state === 'closed') ctx = new AudioContext();
  ctx.resume();
  const p = PATTERNS[msg.sound] || PATTERNS.bark;
  for (let r = 0; r < reps; r++) p.play(ctx.currentTime + 0.05 + r * p.gap, vol);
}
