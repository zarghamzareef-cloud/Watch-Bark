const $ = id => document.getElementById(id);
const FIELDS = ['checkValue', 'checkUnit', 'include', 'exclude', 'locations', 'aiProvider', 'aiKey', 'aiModel', 'aiRule', 'sound', 'volume', 'repeats', 'quietStart', 'quietEnd', 'activeStart', 'activeEnd', 'pushUrl'];
const CHECKS = ['aiDetails', 'aiFailOpen', 'notify', 'persistent', 'quietOn', 'jitter', 'activeOn'];
const NUM = ['checkValue', 'volume', 'repeats'];
const uid = () => Math.random().toString(36).slice(2, 9);

/* ---------- Websites list ---------- */
function watchRow(w) {
  const el = document.createElement('div'); el.className = 'watch'; el.dataset.id = w.id;
  el.innerHTML = `
    <div class="top2">
      <label class="switch" title="On / off"><input type="checkbox" class="en"><span></span></label>
      <input class="name" placeholder="Name, e.g. NHS Jobs">
      <input class="url" type="url" placeholder="Paste the search results page address (https://…)">
      <button type="button" class="test">Test this page</button>
      <button type="button" class="iconbtn more" title="Advanced">⚙</button>
      <button type="button" class="iconbtn del" title="Remove">✕</button>
    </div>
    <div class="adv">
      <div class="field" style="flex:1;margin:0"><label>Job link contains <span class="muted">(optional)</span></label><input class="pattern" placeholder="Leave empty to auto-detect, e.g. /job/ or /vacancy/"></div>
      <div class="field" style="max-width:260px;margin:0"><label>How to read the page</label><select class="method">
        <option value="auto">Automatic (recommended)</option><option value="fetch">Background only (fast, silent)</option><option value="tab">Open in a pinned tab (for sites that need JavaScript or login)</option></select></div>
    </div>
    <div class="res"></div>`;
  el.querySelector('.en').checked = w.enabled !== false;
  el.querySelector('.name').value = w.name || '';
  el.querySelector('.url').value = w.url || '';
  el.querySelector('.pattern').value = w.pattern || '';
  el.querySelector('.method').value = w.method || 'auto';
  el.querySelector('.more').onclick = () => el.classList.toggle('open');
  el.querySelector('.del').onclick = () => el.remove();
  el.querySelector('.url').addEventListener('change', e => { const n = el.querySelector('.name'); if (!n.value) n.value = siteName(e.target.value); });
  el.querySelector('.test').onclick = () => testWatch(el);
  return el;
}
const readWatchRow = el => ({ id: el.dataset.id, enabled: el.querySelector('.en').checked, name: el.querySelector('.name').value.trim(), url: el.querySelector('.url').value.trim(), pattern: el.querySelector('.pattern').value.trim(), method: el.querySelector('.method').value });
const readWatches = () => [...document.querySelectorAll('.watch')].map(readWatchRow).filter(w => w.url);
const originOf = u => { try { const x = new URL(u); return /^https?:$/.test(x.protocol) ? x.origin + '/*' : null; } catch { return null; } };
function askPermission(urls) { // must run directly inside a click
  const origins = [...new Set(urls.map(originOf).filter(Boolean))];
  return origins.length ? chrome.permissions.request({ origins }) : Promise.resolve(true);
}
async function testWatch(el) {
  const w = readWatchRow(el), res = el.querySelector('.res');
  if (!originOf(w.url)) { res.innerHTML = '<span class="err">Please paste a full web address starting with https://</span>'; return; }
  const granted = await askPermission([w.url]);
  if (!granted) { res.innerHTML = '<span class="err">Permission was not given, so Watch &amp; Bark can\'t read this site.</span>'; return; }
  res.textContent = 'Reading the page… (sites that need JavaScript can take ~10 seconds)';
  const r = await chrome.runtime.sendMessage({ type: 'testWatch', watch: w });
  res.innerHTML = '';
  if (!r?.ok) { const e = document.createElement('span'); e.className = 'err'; e.textContent = '⚠ ' + (r?.error || 'Could not read the page'); res.append(e); return; }
  const b = document.createElement('div');
  if (!r.jobs.length) { b.innerHTML = '<span class="err">⚠ No job links found.</span> Try: make sure you\'re logged in to the site, set "How to read the page" to <b>pinned tab</b>, or fill in "Job link contains" (⚙) with part of a job\'s link.'; res.append(b); el.classList.add('open'); return; }
  b.innerHTML = `<b style="color:var(--brand-2)">✓ Found ${r.jobs.length} jobs</b> <span class="muted">(${r.via === 'tab' ? 'read in a pinned tab' : 'read in the background'}, ${r.strategy}). First few:</span>`;
  const ol = document.createElement('ol'); r.jobs.slice(0, 6).forEach(j => { const li = document.createElement('li'); li.textContent = j.title; ol.append(li); });
  res.append(b, ol);
}
$('addWatch').onclick = () => $('watches').append(watchRow({ id: uid(), enabled: true }));
$('quick').onclick = e => {
  const b = e.target.closest('button'); if (!b) return;
  const row = watchRow({ id: uid(), enabled: true, name: b.dataset.name, url: b.dataset.url });
  $('watches').append(row); const u = row.querySelector('.url'); u.focus(); u.select();
  row.querySelector('.res').innerHTML = '<span class="muted">Example search added — change it to your own search on that site (job title, location, filters), then click <b>Test this page</b>.</span>';
};

/* ---------- Settings ---------- */
function read() {
  const s = {};
  FIELDS.forEach(f => s[f] = NUM.includes(f) ? +$(f).value : $(f).value.trim());
  CHECKS.forEach(f => s[f] = $(f).checked);
  s.mode = document.querySelector('input[name=mode]:checked').value;
  s.watches = readWatches();
  return s;
}
function showPanels() {
  const m = document.querySelector('input[name=mode]:checked').value;
  document.querySelectorAll('.panel').forEach(p => p.classList.toggle('on', p.dataset.panel === m));
}
const modelHint = () => {
  const p = $('aiProvider').value;
  $('aiModel').placeholder = DEFAULT_MODELS[p] + ' (default)';
  $('keyHint').innerHTML = (p === 'openai' ? 'Get one at <a href="https://platform.openai.com/api-keys" target="_blank">platform.openai.com</a> → API keys.' : 'Get one at <a href="https://console.anthropic.com/settings/keys" target="_blank">console.anthropic.com</a> → API keys.') + ' <a href="help.html#ai" target="_blank">Step-by-step guide</a>';
};
const customToggle = () => $('customBox').style.display = $('sound').value === 'custom' ? 'block' : 'none';

async function load() {
  $('sound').innerHTML = Object.entries(SOUND_GROUPS).map(([g, o]) => `<optgroup label="${g}">` + Object.entries(o).map(([k, v]) => `<option value="${k}">${v}</option>`).join('') + '</optgroup>').join('');
  const s = await getSettings();
  FIELDS.forEach(f => $(f).value = s[f]);
  CHECKS.forEach(f => $(f).checked = !!s[f]);
  document.querySelector(`input[name=mode][value=${s.mode}]`).checked = true;
  $('volVal').textContent = Math.round(s.volume * 100) + '%';
  $('watches').innerHTML = '';
  (s.watches.length ? s.watches : [{ id: uid(), enabled: true }]).forEach(w => $('watches').append(watchRow(w)));
  const { customSound } = await chrome.storage.local.get('customSound');
  $('customName').textContent = customSound ? '✓ ' + customSound.name : '';
  showPanels(); modelHint(); customToggle(); renderHistory();
}
async function save() {
  const s = read();
  if (!(s.checkValue > 0)) { alert('Please type how often to check, e.g. 30 seconds or 5 minutes.'); return false; }
  const bad = s.watches.find(w => !originOf(w.url));
  if (bad) { alert(`"${bad.url}" isn't a valid web address. Paste the full address starting with https://`); return false; }
  const granted = await askPermission(s.watches.map(w => w.url).concat(s.pushUrl ? [s.pushUrl] : [])); // must be first await (needs the click)
  if (!granted) { alert('Watch & Bark needs permission to read those websites. Click Save again and choose Allow.'); return false; }
  if (s.mode === 'ai' && (!s.aiKey || !s.aiRule) && !confirm('AI rule mode needs both a rule and an API key. Save anyway?')) return false;
  if (s.sound === 'custom' && !(await chrome.storage.local.get('customSound')).customSound) { alert('Choose a sound file first, or pick another sound.'); return false; }
  const old = await getSettings();
  await chrome.storage.local.set({ settings: Object.assign(old, s) });
  const el = $('saved'); el.style.opacity = 1; setTimeout(() => el.style.opacity = 0, 1800);
  return true;
}
async function renderHistory() {
  const { history = [] } = await chrome.storage.local.get('history');
  const box = $('history'); if (!history.length) return;
  box.innerHTML = '';
  history.slice(0, 20).forEach(h => {
    const d = document.createElement('div');
    const t = document.createElement('time'); t.textContent = new Date(h.at).toLocaleString([], { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' });
    const a = document.createElement('a'); a.href = h.url; a.target = '_blank'; a.textContent = h.title;
    const r = document.createElement('span'); r.className = 'muted'; r.textContent = ` — ${h.site || ''}${h.reason ? ' · ' + h.reason : ''}`;
    const w = document.createElement('span'); w.append(a, r); d.append(t, w); box.append(d);
  });
}

document.querySelectorAll('input[name=mode]').forEach(r => r.onchange = showPanels);
$('aiProvider').onchange = modelHint;
$('sound').onchange = customToggle;
$('volume').oninput = e => $('volVal').textContent = Math.round(e.target.value * 100) + '%';
$('customFile').onchange = e => {
  const f = e.target.files[0]; if (!f) return;
  if (f.size > 3 * 1024 * 1024) { alert('That file is over 3 MB. Please choose a shorter sound.'); e.target.value = ''; return; }
  const rd = new FileReader();
  rd.onload = async () => { await chrome.storage.local.set({ customSound: { name: f.name, data: rd.result } }); $('customName').textContent = '✓ ' + f.name; };
  rd.readAsDataURL(f);
};
$('examples').onclick = e => {
  if (e.target.tagName !== 'BUTTON') return;
  const ta = $('aiRule'); ta.value = (ta.value.trim() ? ta.value.trim().replace(/\.?$/, '. ') : '') + e.target.textContent + '.';
  if (/description/i.test(e.target.textContent)) $('aiDetails').checked = true;
};
$('playBtn').onclick = () => chrome.runtime.sendMessage({ type: 'playSound', settings: read() });
$('save').onclick = save;
$('testBtn').onclick = async () => { if (await save()) chrome.runtime.sendMessage({ type: 'testAlert' }); };
$('previewBtn').onclick = async () => {
  const b = $('previewBtn'), box = $('preview'); b.disabled = true; b.textContent = 'Checking…'; box.innerHTML = '';
  const res = await chrome.runtime.sendMessage({ type: 'preview', settings: read() });
  b.disabled = false; b.textContent = 'Try this rule on current jobs';
  if (!res?.ok) { box.innerHTML = '<div class="err"></div>'; box.firstChild.textContent = '⚠ ' + (res?.error || 'Preview failed'); return; }
  if (res.aiError) { const e = document.createElement('div'); e.className = 'err'; e.textContent = '⚠ AI error: ' + res.aiError; box.append(e); }
  const n = res.jobs.filter(j => res.decisions[j.uid]?.match).length;
  const sum = document.createElement('p'); sum.innerHTML = `<b>${n} of ${res.jobs.length}</b> current jobs would make it bark:`; box.append(sum);
  res.jobs.forEach(j => {
    const d = res.decisions[j.uid] || {}; const row = document.createElement('div'); row.className = 'pj';
    const p = document.createElement('span'); p.className = 'pill ' + (d.match ? 'match' : 'skip'); p.textContent = d.match ? '🐶 Bark' : 'Skip';
    const t = document.createElement('div'); const b2 = document.createElement('b'); b2.textContent = j.title;
    const m = document.createElement('div'); m.className = 'muted'; m.textContent = `${j.site}${d.reason ? ' — ' + d.reason : ''}`;
    t.append(b2, m); row.append(p, t); box.append(row);
  });
};
chrome.storage.onChanged.addListener(c => { if (c.history) renderHistory(); });
load();

/* ---------- AI rule writer ---------- */
$('improveBtn').onclick = async () => {
  const wish = $('wish').value.trim(), msg = $('improveMsg'), b = $('improveBtn');
  if (!wish) { $('wish').focus(); return; }
  b.disabled = true; b.textContent = 'Writing…'; msg.textContent = '';
  const r = await chrome.runtime.sendMessage({ type: 'aiImprove', wish, settings: read() });
  b.disabled = false; b.textContent = 'Write my rule';
  if (!r?.ok) { msg.innerHTML = '<span class="err"></span>'; msg.firstChild.textContent = '⚠ ' + (r?.error || 'Failed'); return; }
  $('aiRule').value = r.rule; msg.textContent = '✓ Rule written below — edit it if you like, then click "Try this rule on current jobs".';
};

/* ---------- Phone alerts ---------- */
$('pushTest').onclick = async () => {
  const url = $('pushUrl').value.trim();
  if (!originOf(url)) { alert('Paste the full address first, e.g. https://ntfy.sh/your-topic'); return; }
  if (!(await askPermission([url]))) return;
  await chrome.runtime.sendMessage({ type: 'testPush', url });
  $('pushTest').textContent = 'Sent ✓'; setTimeout(() => $('pushTest').textContent = 'Send test', 2000);
};

/* ---------- Export / import ---------- */
$('exportBtn').onclick = async () => {
  const s = await getSettings();
  if (!$('exportKey').checked) s.aiKey = '';
  delete s.snoozeUntil; delete s.paused;
  const blob = new Blob([JSON.stringify({ app: 'watch-and-bark', version: 4, settings: s }, null, 2)], { type: 'application/json' });
  const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = 'watch-and-bark-settings.json'; a.click();
};
$('importFile').onchange = e => {
  const f = e.target.files[0]; if (!f) return;
  const rd = new FileReader();
  rd.onload = async () => {
    try {
      const d = JSON.parse(rd.result); if (!d.settings || !Array.isArray(d.settings.watches)) throw 0;
      const cur = await getSettings(); const next = Object.assign(cur, d.settings);
      if (!d.settings.aiKey) next.aiKey = cur.aiKey;
      await chrome.storage.local.set({ settings: next }); await load();
      alert('Settings imported. Click "Save settings" so Chrome can ask permission for the websites.');
    } catch { alert('That file is not a Watch & Bark settings file.'); }
    e.target.value = '';
  };
  rd.readAsText(f);
};
