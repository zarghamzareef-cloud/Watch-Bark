const $ = id => document.getElementById(id);
let tab = 'all', aiUids = null;
const ago = t => { const s = Math.round((Date.now() - t) / 1000); return s < 60 ? `${s}s ago` : s < 3600 ? `${Math.round(s / 60)} min ago` : new Date(t).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }); };

async function render() {
  const s = await getSettings();
  const watches = s.watches.filter(w => w.enabled !== false && w.url);
  const g = await chrome.storage.local.get(['newIds', 'decisions', 'lastCheck', 'aiError', ...watches.map(w => 'w_' + w.id)]);
  const newIds = new Set(g.newIds || []), dec = g.decisions || {};
  let jobs = [], errs = [];
  for (const w of watches) { const st = g['w_' + w.id] || {}; (st.jobs || []).forEach(j => jobs.push(j)); if (st.error) errs.push(`${w.name || siteName(w.url)}: ${st.error}`); }
  if (g.aiError) errs.push('AI: ' + g.aiError);

  $('active').checked = !s.paused; $('pauseLbl').textContent = s.paused ? 'Paused' : 'On';
  $('sub').textContent = watches.length ? `Watching ${watches.length} site${watches.length > 1 ? 's' : ''} · every ${fmtEvery(checkSeconds(s))}` : 'No websites added yet';
  $('dot').className = 'dot' + (s.paused || Date.now() < (s.snoozeUntil || 0) ? ' off' : errs.length ? ' err' : '');
  const snoozed = Date.now() < (s.snoozeUntil || 0);
  $('snooze').textContent = snoozed ? 'Resume' : '💤 Snooze 1 h';
  $('snooze').hidden = s.paused;
  $('statusText').textContent = s.paused ? 'Paused — no barking until you turn it back on'
    : snoozed ? `Snoozed until ${new Date(s.snoozeUntil).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}`
    : (s.activeOn && !inWindow(s.activeStart, s.activeEnd)) ? `Sleeping — checks run ${s.activeStart}–${s.activeEnd}`
    : g.lastCheck ? `${jobs.length} jobs on watch · checked ${ago(g.lastCheck)}` : watches.length ? 'Starting… first check in a few seconds' : 'Add a job website in Settings to start';
  const we = $('werrs'); we.innerHTML = ''; errs.forEach(e => { const d = document.createElement('div'); d.className = 'werr'; d.textContent = '⚠ ' + e; we.append(d); });

  const r = $('rule'); r.innerHTML = '';
  const b = document.createElement('b'); b.textContent = 'Bark on:'; const sp = document.createElement('span');
  sp.textContent = s.mode === 'ai' ? (s.aiRule || 'AI rule not set — open Settings') : s.mode === 'keywords' ? [s.include && `+ ${s.include}`, s.exclude && `− ${s.exclude}`, s.locations && `📍 ${s.locations}`].filter(Boolean).join('  ') || 'No keywords set' : 'Every new job';
  sp.title = sp.textContent; r.append(b, sp);

  jobs.sort((a, b) => newIds.has(b.uid) - newIds.has(a.uid));
  if (tab === 'new') jobs = jobs.filter(j => newIds.has(j.uid));
  if (tab === 'match') jobs = jobs.filter(j => dec[j.uid]?.match);
  if (aiUids) { const order = new Map(aiUids.map((u, i) => [u, i])); jobs = jobs.filter(j => order.has(j.uid)).sort((a, b) => order.get(a.uid) - order.get(b.uid)); }
  const ul = $('list'); ul.innerHTML = '';
  if (!watches.length) { ul.innerHTML = '<div class="empty">Paste the search results page of any job website and Watch &amp; Bark will bark when new jobs appear.<br><button class="primary" id="add">+ Add a job website</button></div>'; $('add').onclick = () => chrome.runtime.openOptionsPage(); return; }
  if (!jobs.length) { ul.innerHTML = `<div class="empty">${aiUids ? 'The AI found no listings that fit.' : tab === 'all' ? 'No jobs loaded yet.' : tab === 'new' ? 'No new jobs since you last marked them read.' : 'No matching jobs yet.'}</div>`; return; }
  for (const j of jobs.slice(0, 80)) {
    const d = dec[j.uid], isNew = newIds.has(j.uid);
    const li = document.createElement('li'); li.className = (isNew ? 'new ' : '') + (d && !d.match ? 'skip' : '');
    const a = document.createElement('a'); a.href = j.url; a.target = '_blank';
    const t = document.createElement('div'); t.className = 'jt';
    if (watches.length > 1) { const si = document.createElement('span'); si.className = 'site'; si.textContent = j.site; t.append(si); }
    t.append(j.title);
    const m = document.createElement('div'); m.className = 'jm'; m.textContent = j.snippet.length > 120 ? j.snippet.slice(0, 120) + '…' : j.snippet;
    const row = document.createElement('div'); row.className = 'jr';
    const pill = (cls, txt) => { const p = document.createElement('span'); p.className = 'pill ' + cls; p.textContent = txt; row.append(p); };
    if (isNew) pill('new', 'NEW');
    if (d) pill(d.match ? 'match' : 'skip', d.match ? '✓ ' + (d.reason || 'Match') : 'Skipped · ' + (d.reason || ''));
    a.append(t); if (m.textContent) a.append(m); if (row.childNodes.length) a.append(row);
    li.append(a); ul.append(li);
  }
}
document.querySelectorAll('.tabs button').forEach(b => b.onclick = () => { document.querySelectorAll('.tabs button').forEach(x => x.classList.toggle('on', x === b)); tab = b.dataset.tab; render(); });
$('active').onchange = async e => { const s = await getSettings(); s.paused = !e.target.checked; await chrome.storage.local.set({ settings: s }); render(); };
$('check').onclick = async () => { const b = $('check'); b.disabled = true; b.textContent = 'Checking…'; await chrome.runtime.sendMessage({ type: 'checkNow' }); b.disabled = false; b.textContent = 'Check now'; render(); };
$('read').onclick = async () => { await chrome.runtime.sendMessage({ type: 'markRead' }); render(); };
$('test').onclick = () => chrome.runtime.sendMessage({ type: 'testAlert' });
$('settings').onclick = () => chrome.runtime.openOptionsPage();
chrome.storage.onChanged.addListener(render);
render();

/* ---------- Check interval (type any time) ---------- */
async function initChecker() {
  const s = await getSettings();
  $('cVal').value = s.checkValue; $('cUnit').value = s.checkUnit;
  const save = async () => {
    const v = +$('cVal').value; if (!(v > 0)) return;
    const s2 = await getSettings(); s2.checkValue = v; s2.checkUnit = $('cUnit').value;
    await chrome.storage.local.set({ settings: s2 });
  };
  $('cVal').onchange = save; $('cUnit').onchange = save;
}

/* ---------- Page auto-refresher ---------- */
let curTab;
async function renderRefresh() {
  const { refreshers = {} } = await chrome.storage.local.get('refreshers');
  const mine = curTab && refreshers[curTab.id];
  $('rBtn').classList.toggle('active', Object.keys(refreshers).length > 0);
  $('rTitle').textContent = curTab ? (curTab.title || curTab.url) : '';
  $('rSetup').hidden = !!mine; $('rActive').hidden = !mine;
  if (mine) {
    const every = mine.random ? `${fmtEvery(mine.minSec)}–${fmtEvery(mine.maxSec)}` : fmtEvery(mine.seconds);
    $('rInfo').textContent = `Every ${every} · next in ${fmtLeft(mine.nextAt - Date.now())}${mine.count ? ` · ${mine.count}${mine.maxCount ? '/' + mine.maxCount : ''}×` : ''}`
      + (mine.keyword ? ` · watching for “${mine.keyword}”${mine.kwError ? ' ⚠' : mine.lastFound ? ' (on page now)' : ''}` : '');
    $('rInfo').title = mine.kwError || '';
  }
  const others = Object.entries(refreshers).filter(([id]) => !curTab || +id !== curTab.id);
  const box = $('rOthers'); box.innerHTML = '';
  for (const [id, r] of others) {
    const d = document.createElement('div');
    const t = document.createElement('span'); t.className = 't'; t.textContent = '🔄 ' + (r.title || 'Tab');
    const n = document.createElement('span'); n.className = 'muted'; n.textContent = `${fmtEvery(r.seconds)} · ${fmtLeft(r.nextAt - Date.now())}`;
    const b = document.createElement('button'); b.textContent = 'Stop'; b.onclick = async () => { await chrome.runtime.sendMessage({ type: 'stopRefresh', tabId: id }); renderRefresh(); };
    d.append(t, n, b); box.append(d);
  }
  return !!mine || others.length > 0;
}
async function initRefresh() {
  [curTab] = await chrome.tabs.query({ active: true, currentWindow: true });
  const usable = curTab && /^(https?|file):/.test(curTab.url || '');
  if (!usable) { $('rSetup').innerHTML = '<span class="muted">This page can\'t be auto-refreshed (Chrome pages, the Web Store and new tabs are protected).</span>'; }
  const active = await renderRefresh();
  const { refreshers = {} } = await chrome.storage.local.get('refreshers');
  if (curTab && refreshers[curTab.id]) $('rPanel').hidden = false;
  $('rBtn').classList.toggle('on', !$('rPanel').hidden);
  $('rBtn').onclick = () => { $('rPanel').hidden = !$('rPanel').hidden; $('rBtn').classList.toggle('on', !$('rPanel').hidden); };
  $('rRand').onchange = e => { $('rMax').disabled = !e.target.checked; };
  $('rUnit').onchange = e => { $('rMaxU').textContent = e.target.selectedOptions[0].textContent; };
  if ($('rStart')) $('rStart').onclick = async () => {
    if (!(+$('rVal').value > 0)) { $('rVal').focus(); return; }
    const u = $('rUnit').value, seconds = toSeconds($('rVal').value, u);
    const random = $('rRand').checked, maxSec = toSeconds($('rMax').value, u);
    if (random && maxSec <= seconds) { alert('"Random up to" must be bigger than the first time.'); return; }
    const keyword = $('rKw').value.trim();
    if (keyword) { // reading the page's text needs permission for that site (asked once)
      const origin = new URL(curTab.url).origin + '/*';
      const ok = await chrome.permissions.request({ origins: [origin] }).catch(() => false);
      if (!ok) { alert('Watch & Bark needs permission to read this site to look for your text. Start again without text to just refresh.'); return; }
    }
    await chrome.runtime.sendMessage({ type: 'startRefresh', tabId: curTab.id, cfg: {
      seconds, random, minSec: seconds, maxSec, hard: $('rHard').checked, maxCount: +$('rMaxCount').value || 0,
      keyword, kwMode: $('rKwMode').value, kwStop: $('rKwStop').checked, title: curTab.title || curTab.url, url: curTab.url } });
    renderRefresh();
  };
  $('rStop').onclick = async () => { await chrome.runtime.sendMessage({ type: 'stopRefresh', tabId: curTab.id }); renderRefresh(); };
  setInterval(() => { renderRefresh(); updateNext(); }, 1000);
}
async function updateNext() {
  const { nextCheckAt } = await chrome.storage.local.get('nextCheckAt');
  const s = await getSettings();
  $('cNext').textContent = s.paused ? 'paused' : nextCheckAt ? 'next in ' + fmtLeft(nextCheckAt - Date.now()) : '';
}
initChecker(); initRefresh(); updateNext();

/* ---------- Snooze, help, AI search ---------- */
$('snooze').onclick = async () => { const s = await getSettings(); s.snoozeUntil = Date.now() < (s.snoozeUntil || 0) ? 0 : Date.now() + 3600e3; await chrome.storage.local.set({ settings: s }); render(); };
$('helpBtn').onclick = () => chrome.tabs.create({ url: chrome.runtime.getURL('help.html') });
async function askAI() {
  const q = $('aiQ').value.trim(); if (!q) return;
  const b = $('aiGo'); b.disabled = true; b.textContent = '…';
  const r = await chrome.runtime.sendMessage({ type: 'aiSearch', question: q });
  b.disabled = false; b.textContent = 'Ask';
  $('aiAns').hidden = false;
  if (!r?.ok) { $('aiText').textContent = '⚠ ' + (r?.error || 'AI search failed'); aiUids = null; }
  else { $('aiText').textContent = '✨ ' + (r.answer || 'Here is what I found.'); aiUids = r.uids; }
  render();
}
$('aiGo').onclick = askAI;
$('aiQ').onkeydown = e => { if (e.key === 'Enter') askAI(); };
$('aiClear').onclick = () => { aiUids = null; $('aiAns').hidden = true; $('aiQ').value = ''; render(); };
$('donate').onclick = e => { e.preventDefault(); chrome.tabs.create({ url: chrome.runtime.getURL('help.html#support') }); };
