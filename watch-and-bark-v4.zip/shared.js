const DEFAULTS = {
  watches: [],               // [{id, name, url, pattern, method:'auto'|'fetch'|'tab', enabled}]
  checkValue: 30, checkUnit: 'sec',
  jitter: true,                 // vary timing ±20% so sites don't see a robot-like pattern
  activeOn: false, activeStart: '07:00', activeEnd: '23:00',
  snoozeUntil: 0,
  pushUrl: '',                  // optional phone/chat alert: ntfy topic URL or Discord/Slack webhook
  paused: false,
  mode: 'all',               // 'all' | 'keywords' | 'ai'
  include: '', exclude: '', locations: '',
  aiProvider: 'anthropic', aiKey: '', aiModel: '', aiRule: '',
  aiDetails: false, aiFailOpen: true,
  sound: 'bark', volume: 0.8, repeats: 2,
  persistent: false, notify: true,
  quietOn: false, quietStart: '23:00', quietEnd: '07:00'
};
const DEFAULT_MODELS = { anthropic: 'claude-haiku-4-5', openai: 'gpt-4o-mini' };
const SOUND_GROUPS = {
  '🐶 Dog sounds': { bark: 'Bark (default)', triple: 'Triple bark', bigdog: 'Big dog', puppy: 'Puppy yip', growl: 'Growl + bark', whine: 'Whine', howl: 'Howl' },
  '📡 Tech': { radar: 'Radar ping', scanner: 'Scanner', retro: 'Retro 8-bit', coin: 'Coin', pop: 'Pop' },
  '🎵 Gentle': { chime: 'Chime', marimba: 'Marimba', harp: 'Harp', bell: 'Bell', dingdong: 'Ding-dong', doorbell: 'Doorbell' },
  '🚨 Loud': { alarm: 'Alarm', siren: 'Siren', knock: 'Knock knock' },
  '📁 Yours': { custom: 'My own sound (upload)' }
};
const SOUND_NAMES = Object.assign({}, ...Object.values(SOUND_GROUPS));
async function getSettings() {
  const { settings } = await chrome.storage.local.get('settings');
  return Object.assign({}, DEFAULTS, settings || {});
}
const siteName = url => { try { return new URL(url).hostname.replace(/^www\./, ''); } catch { return 'site'; } };
const UNIT_SEC = { sec: 1, min: 60, hr: 3600 };
const toSeconds = (v, u) => Math.max(1, Math.round((+v || 0) * (UNIT_SEC[u] || 1)));
const checkSeconds = s => s.checkValue != null ? toSeconds(s.checkValue, s.checkUnit) : Math.round((s.minutes || 0.5) * 60);
const fmtEvery = sec => sec < 60 ? `${sec} sec` : sec < 3600 ? `${+(sec / 60).toFixed(1)} min` : `${+(sec / 3600).toFixed(2)} hr`;
const fmtLeft = ms => { const t = Math.max(0, Math.ceil(ms / 1000)), h = t / 3600 | 0, m = (t % 3600) / 60 | 0, x = t % 60; return h ? `${h}:${String(m).padStart(2, '0')}:${String(x).padStart(2, '0')}` : `${m}:${String(x).padStart(2, '0')}`; };
function inWindow(start, end, d = new Date()) {
  const m = t => { const [h, mi] = String(t).split(':').map(Number); return h * 60 + mi; };
  const now = d.getHours() * 60 + d.getMinutes(), a = m(start), b = m(end);
  return a <= b ? now >= a && now < b : now >= a || now < b;
}
// Developer's PayPal page (from the developer's own PayPal QR code)
const DONATE_URL = 'https://www.paypal.com/qrcodes/p2pqrc/3FP9GDFZEWNJC';
